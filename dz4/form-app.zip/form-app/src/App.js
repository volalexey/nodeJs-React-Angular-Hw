import './App.css';
import ProductForm from "./components/ProductForm/ProductForm";
import {useState} from "react";
import Product from "./components/Product/Product";

const arrProducts = [
    {id: 1, title: 'Product 1', brand: 'Brand2', price: 100 },
    {id: 2, title: 'Product 2', brand: 'Brand2', price: 200 },
];

function App() {
    const [products, setProducts] = useState(arrProducts);

    const addProduct = (newProduct) => {
        setProducts([...products, { id: Date.now(), ...newProduct }]);
    };

    const deleteProduct = (id) => {
        setProducts(products.filter((product) => product.id !== id));
    };

    const updateProduct = (id, updatedProduct) => {
        setProducts(
            products.map((product) =>
                product.id === id ? { ...product, ...updatedProduct } : product
            )
        );
    };

  return (
    <div className="App">
        <h1>Products</h1>
        <ProductForm onAddProduct={addProduct} />
        <div>
            {
                products.map((product, index) => (
                    <Product key={index} product={product} onDelete={deleteProduct} onUpdate={updateProduct} />
                ))
            }
        </div>
    </div>
  );
}

export default App;
