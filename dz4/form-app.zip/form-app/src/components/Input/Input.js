import "./Input.css"

const Input = props => {
    const inputType = props.type || 'text';
    const htmlFor = `${inputType}-${Math.random()}`;

    return (
        <div className="inputBox">
            <label htmlFor={htmlFor}>{props.label}:</label>
            <input className={'inputText'} type={inputType} id={htmlFor} value={props.value} onChange={props.onChange}/>
        </div>
    )
}

export default Input;