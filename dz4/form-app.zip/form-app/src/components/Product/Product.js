import {useState} from "react";
import Input from "../Input/Input";
import "./Product.css"

const Product = ({product, onDelete, onUpdate}) => {

    const [isEditing, setIsEditing] = useState(false);
    const [productTitle, setProductTitle] = useState(product.title);
    const [productBrand, setProductBrand] = useState(product.brand);
    const [productPrice, setProductPrice] = useState(product.price);

    const handleEdit = () =>{
        if(isEditing){
            onUpdate(product.id, {title: productTitle, brand: productBrand, price: parseFloat(productPrice) });
        }
        setIsEditing(!isEditing);
    }

    return (

        //products
        <div className="box-product">
            {isEditing ? (
                    <div>
                        <Input
                            key={1}
                            label={"Title"}
                            value={productTitle}
                            onChange={e => setProductTitle(e.target.value)}
                        />
                        <Input
                            key={2}
                            label={"Brand"}
                            value={productBrand}
                            onChange={e => setProductBrand(e.target.value)}
                        />
                        <Input
                            key={3}
                            label={"Price"}
                            type={"number"}
                            value={productPrice}
                            onChange={e => setProductPrice(e.target.value)}
                        />
                    </div>
                ) :

                (
                    <div>
                        <h3>{product.title}</h3>
                        <div>{product.brand}</div>
                        <div>{product.price}</div>

                        <button className={'btn-delete'} onClick={() => onDelete(product.id)}>Delete</button>
                    </div>
                )}
            <button className={'btn-edit'} onClick={handleEdit}>{isEditing ? 'Save' : 'Edit'}</button>
        </div>
    )
}

export default Product;