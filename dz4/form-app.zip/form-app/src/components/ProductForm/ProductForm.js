import {useState} from "react";
import Input from "../Input/Input";
import "./ProductForm.css";

const ProductForm = ({onAddProduct}) => {
    const [productTitle, setProductTitle] = useState("");
    const [productBrand, setProductBrand] = useState("");
    const [productPrice, setProductPrice] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        if (productTitle && productBrand && productPrice) {
            onAddProduct({title: productTitle, brand: productBrand, price: parseFloat(productPrice) });
            setProductTitle('');
            setProductBrand('');
            setProductPrice('');
        }
    };


    return (
        <div className={'box-form'}>
            <h2>Add Product</h2>
            <form  onSubmit={handleSubmit}>
                <Input
                    key={1}
                    label={"Title"}
                    value={productTitle}
                    onChange={e => setProductTitle(e.target.value)}
                />
                <Input
                    key={2}
                    label={"Brand"}
                    value={productBrand}
                    onChange={e => setProductBrand(e.target.value)}
                />
                <Input
                    key={3}
                    label={"Price"}
                    type={"number"}
                    value={productPrice}
                    onChange={e => setProductPrice(e.target.value)}
                />
                <button className={'btn-add'} type={"submit"}>Add Product</button>
            </form>
        </div>

    )
}
export default ProductForm;